<script setup>
import Agents from '../components/Agents.vue'
</script>

<template>
  <main>
    <Agents />
  </main>
</template>
