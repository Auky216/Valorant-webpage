<script setup>
import Test from '../components/Test.vue'
</script>

<template>
  <main>
    <Test />
  </main>
</template>
