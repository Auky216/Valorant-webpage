<script setup>
import PlayerInfo from '../components/PlayerInfo.vue'
</script>

<template>
  <main>
    <PlayerInfo />
  </main>
</template>
